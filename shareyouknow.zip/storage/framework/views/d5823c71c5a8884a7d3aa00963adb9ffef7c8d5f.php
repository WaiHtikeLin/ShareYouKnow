<div class="col-md-3 asidenav">
			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link" href="/profile/<?php echo e(auth()->id()); ?>"><?php echo e(auth()->user()->name); ?></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/profile/<?php echo e(auth()->id()); ?>">My Profile</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/articles/create">Compose</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/articles/myarticles">My Articles</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="/articles/saves">My Saves</a>
				</li>
				<li class="nav-item">
					<a href="<?php echo e(route('logout')); ?>" onclick="
					event.preventDefault();
					$('#logout-form').submit();" class="nav-link">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
				</li>

			</ul>
			<ul>
				<li>
					<a href="/articles/automobile">Automobile</a>
				</li>
				<li>
					<a href="/articles/crime">Crime</a>
				</li>
				<li>
					<a href="/articles/foodie">Foodie</a>
				</li>
				<li>
					<a href="/articles/health">Health</a>
				</li>
				<li>
					<a href="/articles/movies">Movie</a>
				</li>
				<li>
					<a href="/articles/music">Music</a>
				</li>
				<li>
					<a href="/articles/politics">Politics</a>
				</li>
				<li>
					<a href="/articles/science">Science</a>
				</li>
				<li>
					<a href="/articles/sports">Sports</a>
				</li>
				<li>
					<a href="/articles/technology">Technology</a>
				</li>

			</ul>
</div><?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/sidenav.blade.php ENDPATH**/ ?>