<div id="replyform_<?php echo e($id); ?>">
				
		<input type="text" name="reply" id="send_reply_to_<?php echo e($id); ?>">
		<button onclick="sendReply(<?php echo e($id); ?>)" type="button">Send</button>
				</div>

<?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id='reply_<?php echo e($reply->id); ?>'>
	<a href="/profile/<?php echo e($reply->user_id); ?>"><p><img src="<?php echo e($reply->owner->getImage()); ?>" id="profile"><?php echo e($reply->owner->name); ?></p></a>
	<p><?php echo e($post->getUserRating($reply->user_id)); ?></p>
	<p><?php echo e($reply->created_at); ?></p>
	<p class="reply-words"><?php echo e($reply->words); ?></p>
	<p><?php echo e($reply->photo); ?></p>

	<p><button class="stats" id="replylikestat_<?php echo e($reply->id); ?>" onclick="displayLikeStats(<?php echo e($reply->id); ?>,'reply')"><?php echo e($reply->getLikeStats()); ?></button></p>

	<div class="btn-group btn-group-lg" role="group">
					 
		<button class="btn btn-secondary" type="button" onclick="updateLikesForReply(<?php echo e($reply->id); ?>,this)"><?php echo e($reply->isLiked()); ?></button> 

		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$reply)): ?>
		<a id="modal-397945" href="#reply_form_<?php echo e($reply->id); ?>" role="button" class="btn" data-toggle="modal">Edit</a>

		<div class="modal fade" id="reply_form_<?php echo e($reply->id); ?>" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

			<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="myModalLabel">
								Edit Reply
							</h5> 
							<button type="button" class="close" data-dismiss="modal">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<input type="text" value="<?php echo e($reply->words); ?>" id="update_reply_<?php echo e($reply->id); ?>">
						</div>
						<div class="modal-footer">
							 
							<button type="button" class="btn btn-primary" onclick="updateReply(<?php echo e($reply->id); ?>,<?php echo e($reply->comment->id); ?>)" data-dismiss="modal">
								Save changes
							</button> 
							<button type="button" class="btn btn-secondary" onclick="deleteReply(<?php echo e($reply->id); ?>,<?php echo e($reply->comment->id); ?>)" data-dismiss="modal">
								Delete
							</button>
							<button type="button" class="btn btn-secondary" data-dismiss="modal">
								Close
							</button>
						</div>
					</div>
</div>
		</div>
		<?php endif; ?>
		
	</div>
	<div id="reply_likes_<?php echo e($reply->id); ?>"></div>


</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/reply.blade.php ENDPATH**/ ?>