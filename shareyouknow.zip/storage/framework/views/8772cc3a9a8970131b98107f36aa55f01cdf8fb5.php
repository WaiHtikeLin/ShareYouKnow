	
	
	<?php $__env->startSection('content'); ?>
	<div class="row main">
		<?php echo $__env->make('sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="col-md-6 articles">

		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
				<article id="article_<?php echo e($post->id); ?>">
				<a href="/profile/<?php echo e($post->user_id); ?>"><p>
					<img src="<?php echo e($post->owner->getImage()); ?>" id="profile"><?php echo e($post->owner->name); ?></p></a>

				<p><?php echo e($post->created_at); ?></p>
				<h3 class="post-title"><?php echo e($post->title); ?></h3>
				<p id="avg-rating<?php echo e($post->id); ?>"><?php echo e($post->getAvgRating()); ?></p>
				<p class="post-des">
					<?php echo e($post->description); ?>

				</p>
			<p><button onclick="displayStats(<?php echo e($post->id); ?>)" class="stats" id="stat_<?php echo e($post->id); ?>">
					<?php echo $post->getStats(); ?>

				</button></p>

				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rate',$post)): ?>
				<div class="btn-group btn-group-sm rating" role="group" id="rating<?php echo e($post->id); ?>">
					<button class="btn btn-primary rate-btn <?php echo e($post->getRating()!='Bad' ? '': 'active'); ?>" value="<?php echo e($post->id); ?>">Bad</button>
					<button class="btn btn-primary rate-btn <?php echo e($post->getRating()!='Poor' ? '': 'active'); ?>" value="<?php echo e($post->id); ?>">Poor</button>
					<button class="btn btn-primary rate-btn <?php echo e($post->getRating()!='Nice' ? '': 'active'); ?>" value="<?php echo e($post->id); ?>">Nice</button>
					<button class="btn btn-primary rate-btn <?php echo e($post->getRating()!='Good' ? '': 'active'); ?>" value="<?php echo e($post->id); ?>">Good</button>
					<button class="btn btn-primary rate-btn <?php echo e($post->getRating()!='Great' ? '': 'active'); ?>" value="<?php echo e($post->id); ?>">Great</button>
				</div>

				<?php endif; ?>
					
				<div class="btn-group btn-group-md" role="group">
					 
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('rate',$post)): ?>
					<button class="btn btn-outline-dark text-light rate" onclick="updateRateForPost(<?php echo e($post->id); ?>,this)" id="rate<?php echo e($post->id); ?>"><?php echo e($post->getRating()); ?></button>
					<?php endif; ?>

					<button class="btn btn-outline-dark text-light" type="button" onclick="updateLikesForPost(<?php echo e($post->id); ?>,this)"><?php echo e($post->isLiked()); ?></button> 

					

					<button class="btn btn-outline-dark text-light" type="button" onclick="getComments(<?php echo e($post->id); ?>)">Comment</button> 
					

					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$post)): ?>

					<a href="/articles/<?php echo e($post->id); ?>/edit"><button class="btn btn-secondary" type="button">Edit</button></a>

					<?php else: ?>
					<button class="btn btn-outline-dark text-light" type="button" onclick="updateSaves(<?php echo e($post->id); ?>,this)"><?php echo e($post->isSaved()); ?></button>

					<?php endif; ?>
				</div>
				
				
				<div id="stats_<?php echo e($post->id); ?>" ></div>
				<div id="comments_<?php echo e($post->id); ?>" ></div>
				
			</article>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	

		</div>
		<div class="col-md-3 aside">
			<h1>csfvfdvd</h1>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/latest.blade.php ENDPATH**/ ?>