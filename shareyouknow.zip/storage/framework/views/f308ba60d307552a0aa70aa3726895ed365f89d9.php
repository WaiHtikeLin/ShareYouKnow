<?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<p><a href="/profile/<?php echo e($like->user_id); ?>"><img src="<?php echo e($like->liker->getImage()); ?>" id="profile"><?php echo e($like->liker->name); ?></a></p>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/commentstats.blade.php ENDPATH**/ ?>