	
	<?php $__env->startSection('content'); ?>
	<div class="row main">
		<?php echo $__env->make('sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="col-md-6" id="articleform">
			
			<form method="post" action="/articles/<?php echo e($post->id); ?>" accept-charset="UTF-8">
				<?php echo csrf_field(); ?>
				<?php echo method_field('patch'); ?>
			<select name="category">
				<option value="automobile">Automobile</option>
				<option value="music">Music</option>
			</select>

			<input type="text" name="title" value="<?php echo e($post->title); ?>" />
			<textarea name="description"><?php echo e($post->description); ?></textarea>
			<input type="submit" value="Update">
			</form>
			<form method="post" action="/articles/<?php echo e($post->id); ?>">
				<?php echo csrf_field(); ?>
				<?php echo method_field('delete'); ?>
				<input type="submit" value="Delete">

			</form>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/posteditform.blade.php ENDPATH**/ ?>