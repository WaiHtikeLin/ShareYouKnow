<div class="tabbable" id="tabs-71061">
				<ul class="nav nav-tabs">
					<li class="nav-item">
						<a class="nav-link active" href="#tab1_<?php echo e($id); ?>" data-toggle="tab">Likes(<?php echo e($likes->count()); ?>)</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#tab2_<?php echo e($id); ?>" data-toggle="tab">Saves(<?php echo e($saves->count()); ?>)</a>
					</li>
				</ul>
				<div class="tab-content">
					<div class="tab-pane active" id="tab1_<?php echo e($id); ?>">
						<?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a href="/profile/<?php echo e($like->user_id); ?>"><p>
								<img src="<?php echo e($like->liker->getImage()); ?>" id="profile"><?php echo e($like->liker->name); ?></p></a>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="tab-pane" id="tab2_<?php echo e($id); ?>">
						<?php $__currentLoopData = $saves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $save): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a href="/profile/<?php echo e($save->id); ?>"><p>
								<img src="<?php echo e($save->getImage()); ?>" id="profile"><?php echo e($save->name); ?></p></a>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
	
<?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/poststats.blade.php ENDPATH**/ ?>