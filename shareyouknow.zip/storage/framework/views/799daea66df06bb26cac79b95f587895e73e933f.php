<?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a class="dropdown-item" href="/articles/show/<?php echo e($notification->data['source']['id']); ?>"><p>
                    <img src="<?php echo e($notification->data['photo']); ?>" id="profile"><?php echo e($notification->data['msg']); ?></p>
                  <p><?php echo e(\App\ NotiControl::getTime($notification->created_at)); ?></p>
           	</a>
                  <div class="text-right mb-1">
                  	<button class="btn btn-danger btn-sm noti-delete" value="<?php echo e($notification->id); ?>">Delete</button>
                  </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/notification.blade.php ENDPATH**/ ?>