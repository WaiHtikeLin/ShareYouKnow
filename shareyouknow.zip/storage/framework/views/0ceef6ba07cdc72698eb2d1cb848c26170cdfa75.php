<div id="commentform_<?php echo e($post->id); ?>">
				
						<input type="text" name="comment" id="send_to_<?php echo e($post->id); ?>">
						<button onclick="sendComment(<?php echo e($post->id); ?>)" type="button">Send</button>
				</div>
<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div id='comment_<?php echo e($comment->id); ?>'>
	<a href="/profile/<?php echo e($comment->user_id); ?>"><p><img src="<?php echo e($comment->owner->getImage()); ?>" id="profile"><?php echo e($comment->owner->name); ?></p></a>

	<p><?php echo e($post->getUserRating($comment->user_id)); ?></p>
	<p><?php echo e($comment->created_at); ?></p>
	<p class="comment-words"><?php echo e($comment->words); ?></p>
	<p><?php echo e($comment->photo); ?></p>

	<p><button onclick="displayLikeStats(<?php echo e($comment->id); ?>,'comment')" class="stats" id="commentstat_<?php echo e($comment->id); ?>">
		<?php echo $comment->getStats(); ?>


	</button></p>

	<div class="btn-group btn-group-lg" role="group">
					 
		<button class="btn btn-secondary" type="button" onclick="updateLikesForComment(<?php echo e($comment->id); ?>,this)"><?php echo e($comment->isLiked()); ?></button> 

		<button class="btn btn-secondary" type="button" onclick="getReplies(<?php echo e($comment->id); ?>,this)">Reply</button>

		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$comment)): ?>
		<a id="modal-397945" href="#comment_form_<?php echo e($comment->id); ?>" role="button" class="btn" data-toggle="modal">Edit</a>

		<div class="modal fade" id="comment_form_<?php echo e($comment->id); ?>" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

			<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="myModalLabel">
								Edit Comment
							</h5> 
							<button type="button" class="close" data-dismiss="modal">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<input type="text" value="<?php echo e($comment->words); ?>" id="update_comment_<?php echo e($comment->id); ?>">
						</div>
						<div class="modal-footer">
							 
							<button type="button" class="btn btn-primary" onclick="updateComment(<?php echo e($comment->id); ?>,<?php echo e($comment->post->id); ?>)" data-dismiss="modal">
								Save changes
							</button> 
							<button type="button" class="btn btn-secondary" onclick="deleteComment(<?php echo e($comment->id); ?>,<?php echo e($comment->post->id); ?>)" data-dismiss="modal">
								Delete
							</button>
							<button type="button" class="btn btn-secondary" data-dismiss="modal">
								Close
							</button>
						</div>
					</div>
</div>
		</div>
		<?php endif; ?>
	</div>
	
	<div id="comment_likes_<?php echo e($comment->id); ?>" ></div>
	<div id="replies_<?php echo e($comment->id); ?>" class="replies"></div> 


</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/comment.blade.php ENDPATH**/ ?>