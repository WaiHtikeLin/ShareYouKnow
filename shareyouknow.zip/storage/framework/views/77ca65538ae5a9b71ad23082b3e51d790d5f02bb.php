	
	<?php $__env->startSection('content'); ?>
	<div class="row main">
		<?php echo $__env->make('sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="col-md-6 articles">
			<div>
			<p><?php echo e($profile->user->name); ?></p>
			<p><?php echo e($profile->user->email); ?></p>
			<p><?php echo e($profile->ph_no); ?></p>
			<p><?php echo e($profile->address); ?></p>
			<p><?php echo e($profile->about); ?></p>
			</div>

			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$profile)): ?>
			<a id="modal-397945" href="#profile_form_<?php echo e($profile->id); ?>" role="button" class="btn" data-toggle="modal">Edit Profile</a>

		<div class="modal fade" id="profile_form_<?php echo e($profile->id); ?>" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

			<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="myModalLabel">
								Edit Profile
							</h5> 
							<button type="button" class="close" data-dismiss="modal">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<form method="post" action="/profile/<?php echo e($profile->user_id); ?>" enctype="multipart/form-data">

							<?php echo csrf_field(); ?>
							<?php echo method_field('PATCH'); ?>

						<div class="modal-body">

							<?php if($profile->photo): ?>
							<label for="profile">Change profile picture</label>

							<?php else: ?>
							<label for="profile">Add profile picture</label>

							<?php endif; ?>

							<input type="file" name="profile" id="profile">
						</div>

						<div class="modal-body">
							
							<input type="text" value="<?php echo e($profile->ph_no); ?>" name="ph_no" id="update_profile_ph_no_<?php echo e($profile->user_id); ?>">
							<button type="button" onclick="remove('#update_profile_ph_no_<?php echo e($profile->user_id); ?>','a phone number',this)">remove</button>
						</div>
						<div class="modal-body">
							<input type="text" value="<?php echo e($profile->address); ?>" id="update_profile_address_<?php echo e($profile->user_id); ?>" name="address">
							<button type="button" onclick="remove('#update_profile_address_<?php echo e($profile->user_id); ?>','an address',this)">remove</button>
						</div>
						<div class="modal-body">
							<input type="text" value="<?php echo e($profile->about); ?>" id="update_profile_about_<?php echo e($profile->user_id); ?>" name="about">
							<button type="button" onclick="remove('#update_profile_about_<?php echo e($profile->user_id); ?>','about you',this)">remove</button>
						</div>
						<div class="modal-footer">
							 
							<input type="submit" class="btn btn-primary" value="Save">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">
								Close
							</button>
						</div>
					</form>
						</div>
					</div>
</div>
		
			<?php endif; ?>
			
		</div>
		<div class="col-md-3 aside">
			<h1>csfvfdvd</h1>
		</div>
	</div>
	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/profile.blade.php ENDPATH**/ ?>