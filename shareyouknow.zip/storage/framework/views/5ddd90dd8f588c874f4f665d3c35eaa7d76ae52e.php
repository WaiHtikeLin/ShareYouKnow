	
	<?php $__env->startSection('content'); ?>
	<div class="row main">
		<?php echo $__env->make('sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="col-md-6" id="articleform">
			
			<form method="post" action="/articles">
				<?php echo csrf_field(); ?>
			<select name="category">
				<option value="automobile">Automobile</option>
				<option value="music">Music</option>
			</select>

			<input type="text" name="title"/>
			<textarea name="description"></textarea>
			<input type="submit" value="create">
			</form>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/articleform.blade.php ENDPATH**/ ?>