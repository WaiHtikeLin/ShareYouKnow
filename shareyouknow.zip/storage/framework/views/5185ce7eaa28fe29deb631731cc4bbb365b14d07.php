<!-- <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div id='comment_<?php echo e($comment->id); ?>'>
	<p><?php echo e($comment->owner->name); ?></p>
	<p><?php echo e($comment->words); ?></p>
	<p><?php echo e($comment->photo); ?></p>

	<p class="stats">
		<span id="commentlikestat_<?php echo e($comment->id); ?>"><?php echo e($comment->getLikeStats()); ?></span>
		<span  id="replystat_<?php echo e($post->id); ?>"><?php echo e($comment->getReplyStats()); ?></span>
	</p>

	<div class="btn-group btn-group-lg" role="group">
					 
		<button class="btn btn-secondary" type="button" onclick="updateLikesForComment(<?php echo e($comment->id); ?>,this)"><?php echo e($comment->isLiked()); ?></button> 

		<button class="btn btn-secondary" type="button" onclick="getReplies(<?php echo e($comment->id); ?>)">Reply</button> 
	</div>


</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
<h1>bhcvhsgc</h1><?php /**PATH C:\xampp\htdocs\shareyouknow\resources\views/coment.blade.php ENDPATH**/ ?>