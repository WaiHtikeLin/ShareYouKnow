@extends('layouts.main')
	
	@section('content')
	<div class="row main">
		@include('sidenav')
		<div class="col-md-6" id="articleform">
			
			<form method="post" action="/articles">
				@csrf
			<select name="category">
				<option value="automobile">Automobile</option>
				<option value="music">Music</option>
			</select>

			<input type="text" name="title"/>
			<textarea name="description"></textarea>
			<input type="submit" value="create">
			</form>
		</div>
	</div>
	@endsection