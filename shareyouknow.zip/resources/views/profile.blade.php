@extends('layouts.main')
	
	@section('content')
	<div class="row main">
		@include('sidenav')
		<div class="col-md-6 articles">
			<div>
			<p>{{ $profile->user->name }}</p>
			<p>{{ $profile->user->email }}</p>
			<p>{{ $profile->ph_no }}</p>
			<p>{{ $profile->address }}</p>
			<p>{{ $profile->about }}</p>
			</div>

			@can('update',$profile)
			<a id="modal-397945" href="#profile_form_{{ $profile->id }}" role="button" class="btn" data-toggle="modal">Edit Profile</a>

		<div class="modal fade" id="profile_form_{{ $profile->id }}" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

			<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="myModalLabel">
								Edit Profile
							</h5> 
							<button type="button" class="close" data-dismiss="modal">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<form method="post" action="/profile/{{ $profile->user_id }}" enctype="multipart/form-data">

							@csrf
							@method('PATCH')

						<div class="modal-body">

							@if($profile->photo)
							<label for="profile">Change profile picture</label>

							@else
							<label for="profile">Add profile picture</label>

							@endif

							<input type="file" name="profile" id="profile">
						</div>

						<div class="modal-body">
							
							<input type="text" value="{{ $profile->ph_no }}" name="ph_no" id="update_profile_ph_no_{{ $profile->user_id }}">
							<button type="button" onclick="remove('#update_profile_ph_no_{{ $profile->user_id }}','a phone number',this)">remove</button>
						</div>
						<div class="modal-body">
							<input type="text" value="{{ $profile->address }}" id="update_profile_address_{{ $profile->user_id }}" name="address">
							<button type="button" onclick="remove('#update_profile_address_{{ $profile->user_id }}','an address',this)">remove</button>
						</div>
						<div class="modal-body">
							<input type="text" value="{{ $profile->about }}" id="update_profile_about_{{ $profile->user_id }}" name="about">
							<button type="button" onclick="remove('#update_profile_about_{{ $profile->user_id }}','about you',this)">remove</button>
						</div>
						<div class="modal-footer">
							 
							<input type="submit" class="btn btn-primary" value="Save">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">
								Close
							</button>
						</div>
					</form>
						</div>
					</div>
</div>
		
			@endcan
			
		</div>
		<div class="col-md-3 aside">
			<h1>csfvfdvd</h1>
		</div>
	</div>
	@endsection
