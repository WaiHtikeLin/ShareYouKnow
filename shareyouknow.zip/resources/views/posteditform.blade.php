@extends('layouts.main')
	
	@section('content')
	<div class="row main">
		@include('sidenav')
		<div class="col-md-6" id="articleform">
			
			<form method="post" action="/articles/{{ $post->id }}" accept-charset="UTF-8">
				@csrf
				@method('patch')
			<select name="category">
				<option value="automobile">Automobile</option>
				<option value="music">Music</option>
			</select>

			<input type="text" name="title" value="{{ $post->title }}" />
			<textarea name="description">{{ $post->description }}</textarea>
			<input type="submit" value="Update">
			</form>
			<form method="post" action="/articles/{{ $post->id }}">
				@csrf
				@method('delete')
				<input type="submit" value="Delete">

			</form>
		</div>
	</div>
	@endsection